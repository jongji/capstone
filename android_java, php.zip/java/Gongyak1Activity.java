package com.example.gandi.votingapp;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import android.app.ProgressDialog;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.widget.ImageView;

import android.widget.TextView;
import android.widget.Toast;


public class Gongyak1Activity extends AppCompatActivity {


    private static final String TAG_RESULTS="result";
    private static final String TAG_NAME = "name";
    private static final String TAG_INFO = "info";
    private static final String TAG_PROMISE ="promise";




    public static final String baseURL = "http://221.154.33.240/1.png";
    private ProgressDialog progressDialog;

    ImageView imageView;
    TextView textView;
    TextView textView2;
    TextView textView3;
    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gongyak1);
        imageView = (ImageView) findViewById(R.id.promiss);
        textView = (TextView) findViewById(R.id.name);
        textView2 = (TextView) findViewById(R.id.department);
        textView3 = (TextView) findViewById(R.id.info);
        setCandiInfo();
        setCandiInfo2();
        setCandiInfo3();

        Thread mThread = new Thread() {
            public void run(){
                try {
                    URL url = new URL(baseURL);
                    HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                    conn.setDoInput(true);

                    InputStream is = conn.getInputStream();
                    bitmap = BitmapFactory.decodeStream(is);


                }
                catch(IOException ex) {

                }
            }
        };

        mThread.start();

        try {
            mThread.join();
            imageView.setImageBitmap(bitmap);
        } catch (InterruptedException e) {

        }
    }

    private void setCandiInfo() {

        class CandiInfo extends AsyncTask<String, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(Gongyak1Activity.this, "잠시만 기다려 주세요..", "Loading...");
            }




            @Override
            protected String doInBackground(String... params) {

                try{
                    String link="http://221.154.33.240/candi1.php";

                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    String result = null;

                    // Read Server Response
                    while((line = reader.readLine()) != null)
                    {
                        sb.append(line);
                        break;
                    }
                    result = sb.toString();

                    return result;
                }
                catch(Exception e){
                    return new String("Exception: " + e.getMessage());
                }
            }

            @Override
            protected void onPostExecute(String result) {
                //super.onPostExecute(result);
                loading.dismiss();

                String s = result.trim();
                System.out.println(s);
                textView.setText(s);

                //Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();
            }


        }
        CandiInfo task = new CandiInfo();
        task.execute();
    }

    private void setCandiInfo2() {

        class CandiInfo extends AsyncTask<String, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(Gongyak1Activity.this, "잠시만 기다려 주세요..", "Loading...");
            }




            @Override
            protected String doInBackground(String... params) {

                try{
                    String link="http://221.154.33.240/candi1_1.php";

                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    String result = null;

                    // Read Server Response
                    while((line = reader.readLine()) != null)
                    {
                        sb.append(line);
                        break;
                    }
                    result = sb.toString();

                    return result;
                }
                catch(Exception e){
                    return new String("Exception: " + e.getMessage());
                }
            }

            @Override
            protected void onPostExecute(String result) {
                //super.onPostExecute(result);
                loading.dismiss();

                String s = result.trim();
                System.out.println(s);
                textView2.setText(s);

                //Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();
            }


        }
        CandiInfo task = new CandiInfo();
        task.execute();
    }

    private void setCandiInfo3() {

        class CandiInfo extends AsyncTask<String, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(Gongyak1Activity.this, "잠시만 기다려 주세요..", "Loading...");
            }




            @Override
            protected String doInBackground(String... params) {

                try{
                    String link="http://221.154.33.240/candi1_2.php";

                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    String result = null;

                    // Read Server Response
                    while((line = reader.readLine()) != null)
                    {
                        sb.append(line);
                        break;
                    }
                    result = sb.toString();

                    return result;
                }
                catch(Exception e){
                    return new String("Exception: " + e.getMessage());
                }
            }

            @Override
            protected void onPostExecute(String result) {
                //super.onPostExecute(result);
                loading.dismiss();

                String s = result.trim();
                System.out.println(s);
                textView3.setText(s);

                //Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();
            }


        }
        CandiInfo task = new CandiInfo();
        task.execute();
    }



}
