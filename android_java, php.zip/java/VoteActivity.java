package com.example.gandi.votingapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;



import static android.media.CamcorderProfile.get;
import static com.example.gandi.votingapp.R.layout.dialog_addmember;
import static com.example.gandi.votingapp.R.layout.activity_vote;

public class VoteActivity extends Activity {


    String myJSON;

    public static final String USER_NAME = "USERNAME";
    private static final String TAG_RESULTS="result";
    private static final String TAG_NAME = "name";
    private static final String TAG_SDATE = "sdate";
    private static final String TAG_EDATE ="edate";
    private String data = null;

    JSONArray peoples = null;

    ArrayList<HashMap<String, String>> personList;

    ListView list;

    String user_name;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(activity_vote);

        Intent intent = getIntent();
        String username = intent.getStringExtra(MenuActivity.USER_NAME);

        user_name = username;

        list = (ListView) findViewById(R.id.ListView);
        personList = new ArrayList<HashMap<String,String>>();
        getData("http://221.154.33.240/getlistview_vote.php");
    }

    //onClick 속성이 부여된 View를 클릭했을 때 자동으로 호출되는 메소드
    public void mOnClick(final View v) {
        switch (v.getId()) {
            case R.id.votebutton:

                LayoutInflater inflater = getLayoutInflater();
                final View dialogView = inflater.inflate(dialog_addmember, null);


                //세부내역 입력 Dialog 생성 및 보이기
                AlertDialog.Builder buider = new AlertDialog.Builder(this); //AlertDialog.Builder 객체 생성
                buider.setTitle("투표할 후보를 선택하세요"); //Dialog 제목
                buider.setView(dialogView); //위에서 inflater가 만든 dialogView 객체 세팅 (Customize)

                //투표완료시

                buider.setPositiveButton("투표", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        RadioGroup rg = (RadioGroup) dialogView.findViewById(R.id.dialog_rg);

                        RadioButton rb1 = (RadioButton) rg.findViewById(R.id.candi1);
                        RadioButton rb2 = (RadioButton) rg.findViewById(R.id.candi2);
                        RadioButton rb3 = (RadioButton) rg.findViewById(R.id.candi3);

                        data = null;

                        if(rb1.isChecked())
                            data = "1번";
                        else if(rb2.isChecked())
                            data = "2번";
                        else if(rb3.isChecked())
                            data = "3번";

                        System.out.println(data);
                        System.out.println(user_name);

                        insertToDatabase(data, user_name);



                        //Toast.makeText(VoteActivity.this, "투표를 완료하였습니다.", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                        intent.putExtra(USER_NAME, user_name);
                        startActivity(intent);


                    }
                });


                //투표 취소시
                buider.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(VoteActivity.this, "투표가 취소되었습니다.", Toast.LENGTH_SHORT).show();
                    }
                });


                //설정한 값으로 AlertDialog 객체 생성
                AlertDialog dialog=buider.create();

                //Dialog의 바깥쪽을 터치했을 때 Dialog를 없앨지 설정
                dialog.setCanceledOnTouchOutside(false);//없어지지 않도록 설정

                dialog.show();
                break;

        }//switch
    }//mOnClickMethod

    private void insertToDatabase(String data, String user_name) {

        class InsertData extends AsyncTask<String, Void, String>{
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(VoteActivity.this, "잠시만 기다려 주세요..", "Loading...");
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(String... params) {

                try{
                    String votedata = (String)params[0];
                    String user_name = (String)params[1];

                    String link="http://192.168.80.209/votedata_insert.php";
                    String data  = URLEncoder.encode("data", "UTF-8") + "=" + URLEncoder.encode(votedata, "UTF-8");
                    data += "&" + URLEncoder.encode("user_name", "UTF-8") + "=" + URLEncoder.encode(user_name, "UTF-8");

                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();
                    conn.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                    wr.write( data );
                    wr.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    // Read Server Response
                    while((line = reader.readLine()) != null)
                    {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                }
                catch(Exception e){
                    return new String("Exception: " + e.getMessage());
                }

            }
        }

        InsertData task = new InsertData();
        task.execute(data, user_name);
    }


    protected void showList(){
        try {
            JSONObject jsonObj = new JSONObject(myJSON);
            peoples = jsonObj.getJSONArray(TAG_RESULTS);

            for(int i=0;i<peoples.length();i++){
                JSONObject c = peoples.getJSONObject(i);
                String name = c.getString(TAG_NAME);
                String sdate = c.getString(TAG_SDATE);
                String edate = c.getString(TAG_EDATE);

                HashMap<String,String> persons = new HashMap<String,String>();

                persons.put(TAG_NAME, name);
                persons.put(TAG_SDATE, sdate);
                persons.put(TAG_EDATE, edate);

                personList.add(persons);
            }

            ListAdapter adapter = new SimpleAdapter(
                    VoteActivity.this, personList, R.layout.list_item,
                    new String[]{TAG_NAME,TAG_SDATE,TAG_EDATE},
                    new int[]{R.id.name, R.id.sdate, R.id.edate}
            );

            list.setAdapter(adapter);
            list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    if(position == 0) {
                        Intent intent = new Intent(
                            getApplicationContext(),
                            Gongyak1Activity.class);
                        startActivity(intent);
                    }
                    if(position == 1) {
                        Intent intent = new Intent(
                                getApplicationContext(),
                                Gongyak2Activity.class);

                        startActivity(intent);
                    }
                }
            });

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    public void getData(String url){
        class GetDataJSON extends AsyncTask<String, Void, String>{

            @Override
            protected String doInBackground(String... params) {

                String uri = params[0];

                BufferedReader bufferedReader = null;
                try {
                    URL url = new URL(uri);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();

                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    String json;
                    while((json = bufferedReader.readLine())!= null){
                        sb.append(json+"\n");
                    }

                    return sb.toString().trim();

                }catch(Exception e){
                    return null;
                }



            }

            @Override
            protected void onPostExecute(String result){
                myJSON=result;
                showList();
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute(url);
    }

}