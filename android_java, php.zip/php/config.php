<?php
	define("DB_HOST", "localhost");
	define("DB_USER", "root");
	define("DB_PASSWORD", "jongji");
	define("DB_NAME", "fcm");

	define("GOOGLE_API_KEY", "AAAADjvcVZs:APA91bFl6t1euUs44rhI94byj46HyIJUO-fDqvPWZnH5OanfIHU6Id_zSCH8DJYIwSDZAxVXHkm741nzYakfZv0btcabp49N1PYRNmcR-Pyi3CoY-0A9B-z6LJL8uvCPhOq2phvNXURS"); 

?>