<?php  
$con=mysqli_connect("127.0.0.1","root","jongji","votingsystem");  
 
mysqli_set_charset($con,"utf8");
  
if (mysqli_connect_errno($con))  
{  
   echo "Failed to connect to MySQL: " . mysqli_connect_error();  
}
$username = $_POST['user_name']; 
$vote_data = $_POST['data'];

$sql = " select studentID from user where studentID='$username'";

$q = mysqli_query($con, $sql);

$row = mysqli_fetch_array($q, MYSQLI_ASSOC);

$hash2 = $row["studentID"];

$hash = password_hash($username, PASSWORD_BCRYPT); # 학번 암호화하기

$f = mysqli_query($con, "select vote from user where studentID='$username'");

$row2 = mysqli_fetch_array($f, MYSQLI_ASSOC);

$hash3 = $row2["vote"];

switch($hash3)
{

case 'yes' :
	echo '이미 투표하셨습니다.';
	break;
	
case 'not' :

	mysqli_query($con, "update user set vote='yes' where studentID=$username");
	$result = mysqli_query($con, "insert into user_vote (studentID, vote_result) values ('$hash', '$vote_data')"); 
	if($result) 
		echo '투표를 완료하였습니다.';
	
		break;
		
	
}

mysqli_close($con);  

?> 