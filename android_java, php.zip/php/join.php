<?php  
$con=mysqli_connect("127.0.0.1","root","jongji","votingsystem");  
 
mysqli_set_charset($con,"utf8");
  
if (mysqli_connect_errno($con))  
{  
   echo "Failed to connect to MySQL: " . mysqli_connect_error();  
}
$studentid = $_POST['studentid'];
$username = $_POST['username'];  
$password = $_POST['password'];

$hash = password_hash($password, PASSWORD_BCRYPT); # 비밀번호 암호화하기

$result = mysqli_query($con,"insert into user (studentID, name, passwd) values ('$studentid', '$username', '$hash')");  
  
  if($result){  
    echo '회원가입이 완료되었습니다.';  
  }  
  else{  
    echo '회원가입 실패';  
  }  
  
mysqli_close($con);  
?> 