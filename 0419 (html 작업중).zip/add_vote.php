<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
  <HEAD>
    <title>:::: 투표설정하기 ::::</title>
    <meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
    <meta name="CODE_LANGUAGE" Content="C#">
    <meta name=vs_defaultClientScript content="JavaScript">
    <meta name=vs_targetSchema content="http://schemas.microsoft.com/intellisense/ie5">
    <LINK href="../include/text.css" type=text/css rel=stylesheet >
    <style type="text/css">
	</style>
    <script language="javascript" src="/include/js.js"></script>
    <script language=javascript>
	</script>
  </HEAD>
  <body leftmargin="5" topmargin="5" bgcolor="white" MS_POSITIONING="FlowLayout" onload="PollModeChk();">
    <form name="Form1" method="post" action="talkPollPop.aspx" id="Form1">
<input type="hidden" name="__VIEWSTATE" value="dDwtNjU0MzcyMTk1Ozs+VjUwaEP7ydea2p6/yczDr8m6SvY=" />
  <table width="250"  border="0" cellpadding="0" cellspacing="0" style="border:1 solid #B9405F; border-collapse:collapse">
   <tr>
    <td width="248" align="center" valign="middle">
     <table width="248" border="0" cellpadding="0" cellspacing="0" style="border:1 solid #DEAEB9; border-collapse:collapse">
      <tr> 
       <td height="27" colspan="2">
       </td>
      </tr>
      <tr> 
       <td height="12"></td>
      </tr>
      <tr>
       <td valign="top" align="center" style="padding-left:5pt">
        <table border="0" cellpadding="0" cellspacing="0" id="tblTemplate">
         <tr>
          <td width="246" height="25"><font class="font">선거 제목(?)</font> <input type="text" name="pollitem_1" id="pollitem_1" size="30" onfocus="PrevItemChk(1)" class="input"></td>
         </tr>
         <tr> 
          <td width="246" height="25"><font class="font">기호</font> <input type="text" name="pollitem_2" id="pollitem_2" size="30" onfocus="PrevItemChk(2)" class="input"></td>
         </tr>
         <tr> 
          <td width="246" height="25"><font class="font">회장 후보 이름</font> <input type="text" name="pollitem_3" id="pollitem_3" size="30" onfocus="PrevItemChk(3)" class="input"></td>
         </tr>
         <tr> 
          <td width="246" height="25"><font class="font">부회장 후보 이름</font> <input type="text" name="pollitem_4" id="pollitem_4" size="30" onfocus="PrevItemChk(4)" class="input"></td>
         </tr>
         <tr> 
          <td width="246" height="25"><font class="font">회장 후보 전공</font> <input type="text" name="pollitem_5" id="pollitem_5" size="30" onfocus="PrevItemChk(5)" class="input"></td>
         </tr>
         <tr> 
          <td width="246" height="25"><font class="font">부회장 후보 전공</font> <input type="text" name="pollitem_6" id="pollitem_6" size="30" onfocus="PrevItemChk(6)" class="input"></td>
         </tr>
         <tr> 
          <td width="246" height="25"><font class="font">회장 소개</font> <input type="text" name="pollitem_7" id="pollitem_7" size="30" onfocus="PrevItemChk(7)" class="input"></td>
         </tr>
         <tr> 
          <td width="246" height="25"><font class="font">부회장 소개</font> <input type="text" name="pollitem_8" id="pollitem_8" size="30" onfocus="PrevItemChk(8)" class="input"></td>
         </tr>
         <tr> 
          <td width="246" height="25"><font class="font">공약</font><br>
		  <input type="text" name="pollitem_9" id="pollitem_9" style="text-align:center; width:220; height:300; letter-spacing: -5px" onfocus="PrevItemChk(9)" class="input">
		  </td>
         </tr>
        </table>
       </td>
      <tr> 
       <td height="32">
        <table width="246" border="0" cellspacing="0" cellpadding="0">
         <tr> 
          <td width="115" align="right"><a href="javascript:;" onclick="addItem();" class="font">[등록]</a></td>
          <td width="16">&nbsp;</td>
         </tr>
        </table>
       </td>
      </tr>
      <tr align="center" valign="top">
      </tr>
      <tr>
       <td height="14"></td>
      </tr>
     </table>
    </td>
   </tr>
  </table>
     </form>
  </body>
</HTML>