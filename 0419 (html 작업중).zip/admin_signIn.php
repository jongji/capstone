<!doctype html>
<html>
<head>
    <meta charset="utf-8" />
    <title>메인 페이지(관리자)</title>
</head>
<body>
	<button type="button" onclick="location.href='notice.php'">공지사항</button>
	<button type="button" onclick="location.href='admin_vote.php'">선거관리</button><BR>
	<button type="button" onclick="location.href='survey.php'">설문조사</button>
	<button type="button" onclick="location.href='suggest.php'">건의사항</button><BR>
</body>
