<HTML>
<HEAD>
<TITLE>XX회 회장 투표</TITLE>
 </HEAD>

<BODY>
 <H2>후보 목록 (회장/부회장)</H2>
<form name="member" method="post" action="member.asp"> 

   <tr>
     <td>
     <INPUT name="ans" type="radio" value="1">
     <font size="2">1.AAA/BBB</font><br>
   
     <INPUT name="ans" type="radio" value="2">
     <font size="2">2.CCC/DDD<br></font>
	 </td>
   </tr>
   <tr>
    <td>
    <INPUT type="button" value="투표하기" on click="check()">
    <INPUT type="button" value="취소" on click="history.back();">
    </td>
   </tr>    
</table>
</form>
</BODY>
</HTML>