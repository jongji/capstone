<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
  <HEAD>
    <title>:::: 현재 후보 목록 ::::</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
    <meta name="CODE_LANGUAGE" Content="C#">
    <meta name=vs_defaultClientScript content="JavaScript">
    <meta name=vs_targetSchema content="http://schemas.microsoft.com/intellisense/ie5">
    <LINK href="../include/text.css" type=text/css rel=stylesheet >
    <style type="text/css">
	</style>
    <script language="javascript" src="/include/js.js"></script>
    <script language=javascript>
	</script>
  </HEAD>
  <body leftmargin="5" topmargin="5" bgcolor="white" MS_POSITIONING="FlowLayout" onload="PollModeChk();">
    <form name="Form1" method="post" action="talkPollPop.aspx" id="Form1">
<input type="hidden" name="__VIEWSTATE" value="dDwtNjU0MzcyMTk1Ozs+VjUwaEP7ydea2p6/yczDr8m6SvY=" />
  <table width="250"  border="0" cellpadding="0" cellspacing="0" style="border:1 solid #B9405F; border-collapse:collapse">
   <tr>
    <td width="248" align="center" valign="middle">
     <table width="248" border="0" cellpadding="0" cellspacing="0" style="border:1 solid #DEAEB9; border-collapse:collapse">
      <tr> 
       <td height="27" colspan="2">
       </td>
      </tr>
      <tr> 
       <td height="12"></td>
      </tr>
      <tr>
       <td valign="top" align="center" style="padding-left:5pt">
        <table border="0" cellpadding="0" cellspacing="0" id="tblTemplate">
			<th width="120" height="25"><font class="font">기호</font></th>
			<th width="120" height="25"><font class="font">회장/부회장</font></th>
        </table>
       </td>
      <tr> 
       <td height="32">
        <table width="246" border="0" cellspacing="0" cellpadding="0">
         <tr> 
		  <button type="button" onclick="location.href='add_vote.php'">후보 등록</button>
          <td width="16">&nbsp;</td>
         </tr>
        </table>
       </td>
      </tr>
      <tr align="center" valign="top">
      </tr>
      <tr>
       <td height="14"></td>
      </tr>
     </table>
    </td>
   </tr>
  </table>
     </form>
  </body>
</HTML>